--hellow world
ipc.log("Hellow world. This script was run via FSUIPC Java SDK!")