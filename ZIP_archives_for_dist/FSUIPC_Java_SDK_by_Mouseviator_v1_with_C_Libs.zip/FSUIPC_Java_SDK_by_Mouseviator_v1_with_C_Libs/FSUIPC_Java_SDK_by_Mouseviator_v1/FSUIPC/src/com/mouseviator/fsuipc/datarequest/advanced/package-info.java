/**
 * This package contains above the primitive data type requests... that type of data requests that have more complex structure :) While it depends on viewer...
 * The only class present right now is the {@link FSControlRequest} class at it is "not that complex" in the end of the day.
 */
package com.mouseviator.fsuipc.datarequest.advanced;
