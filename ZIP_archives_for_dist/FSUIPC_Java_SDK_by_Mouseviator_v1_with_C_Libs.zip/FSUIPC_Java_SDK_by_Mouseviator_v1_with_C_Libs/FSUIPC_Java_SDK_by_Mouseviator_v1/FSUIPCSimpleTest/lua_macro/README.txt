This folder contains lua scripts and macro used in the FSUIPCLVarLuaMacroTest.java example.
You need to put these files inside the FSUIPC folder for your simulator in order to test the example.